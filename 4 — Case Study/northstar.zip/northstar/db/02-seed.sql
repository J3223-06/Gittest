-- NorthStar Outfitters — seed data.
--
-- Deterministic. Every row is a function of its index, so an instructor can
-- say "product 47" and mean the same thing in every cohort, and a learner can
-- write an assertion about it that does not rot.
--
-- laptop without making the seed slow. See the products block for the sizing
-- argument, which is the one number in this file that is not arbitrary.

-- ---------------------------------------------------------------- customers
-- Password for every seeded customer is 'northstar'.
-- Computed at load time by encode(sha256(...)), so the value cannot drift
-- from the algorithm. The literal hex is deliberately NOT written here: the
-- first version of this comment stated one, and it was the SHA-256 of nothing.
INSERT INTO customers (email, password_hash, full_name)
SELECT
    'customer' || i || '@northstar.test',
    encode(sha256('northstar'::bytea), 'hex'),
    (ARRAY['Avery','Blake','Casey','Devin','Ellis','Frankie','Gray','Harper',
           'Indigo','Jules'])[1 + (i % 10)] || ' ' ||
    (ARRAY['Nolan','Okafor','Park','Quinn','Reyes','Sandoval','Tran','Ueda',
           'Vasquez','Whitfield'])[1 + ((i * 7) % 10)]
FROM generate_series(1, 400) AS i;

-- One named customer the manual test cases and the answer key refer to.
INSERT INTO customers (email, password_hash, full_name)
VALUES ('reviewer@northstar.test', encode(sha256('northstar'::bytea), 'hex'),
        'Reviewer Account');

INSERT INTO admin_users (email, password_hash, full_name)
VALUES ('admin@northstar.test', encode(sha256('northstar-admin'::bytea), 'hex'),
        'Store Administrator');

-- ---------------------------------------------------------------- products
-- 40,000 products across six categories. Prices $10.00–$899.97:
-- the formula can only land on 999 cents at exact multiples of 89000,
-- which the series never hits, so the advertised $9.99 floor never occurs.
-- The size is chosen, not arbitrary. Below roughly ten thousand rows an
-- unindexed scan is fast enough that no load test would flag it. No
-- smaller size has been measured here; 40,000 is what the seed builds and
-- what verify_defects.py times. Historically the note read: at 8,000 a scan returns in
-- about 8 ms, which no load test would ever flag. At 40,000 it is slow
-- enough to show up as a p95 problem and still seeds in a few seconds.
INSERT INTO products (sku, name, category, description, price_cents, stock, active)
SELECT
    'NS-' || lpad(i::text, 6, '0'),
    (ARRAY['Alpine','Summit','Trailhead','Northwind','Glacier','Ridgeline',
           'Basecamp','Timberline'])[1 + (i % 8)] || ' ' ||
    (ARRAY['Down Jacket','Trail Pack','Rain Shell','Sleeping Bag','Hiking Boot',
           'Tent','Trekking Pole','Base Layer','Headlamp','Water Filter'])[1 + ((i * 3) % 10)] || ' ' ||
    (ARRAY['20L','30L','45L','Mk II','Mk III','Ultralight','Expedition',
           'Womens','Mens','Junior'])[1 + ((i * 11) % 10)],
    (ARRAY['outerwear','packs','footwear','shelter','sleep','accessories'])[1 + (i % 6)],
    'Field-tested outdoor equipment. Item ' || i || '.',
    999 + ((i * 3137) % 89000),
    -- Deliberately uneven stock. About one product in twenty is out of stock,
    CASE
        WHEN i % 20 = 0 THEN 0
        WHEN i % 97 = 0 THEN 1
        ELSE 5 + ((i * 13) % 60)
    END,
    -- One in fifty is inactive: visible to admin, must not appear in search.
    (i % 50) <> 0
FROM generate_series(1, 40000) AS i;

-- Three products the case study names explicitly, at fixed ids, so the manual
-- test cases and the answer key can point at them.
INSERT INTO products (sku, name, category, description, price_cents, stock, active)
VALUES
  ('NS-TENT-01', 'Northwind 2-Person Tent', 'shelter',
   'Three-season, 2.4 kg, taped seams.', 34999, 12, TRUE),
  ('NS-BOOT-01', 'Summit GTX Hiking Boot', 'footwear',
   'Waterproof, Vibram sole.', 21999, 1, TRUE),
  ('NS-LAMP-01', 'Glacier Headlamp 400', 'accessories',
   '400 lumens, USB-C, 40 h burn.', 5499, 0, TRUE);

-- ---------------------------------------------------------------- discounts
-- The expiry boundary is the point of this table. TRAIL20 expires on the day
-- the seed is LOADED, which is not the same as the day the class runs.
--
-- An earlier version of this comment claimed the boundary would "always be
-- today and the defect always reproducible". That is true for one day. Seed on
-- correctly, the answer key says it is reproducible, and the instructor finds
-- out in front of the room.
--
-- `run.sh` now re-stamps these four dates relative to CURRENT_DATE on every
-- start, so the boundary really is always today. The values below are the
-- shape; run.sh is what keeps them true.
INSERT INTO discount_codes (code, percent_off, expires_on, min_subtotal_cents, active)
VALUES
  ('WELCOME10',  10, CURRENT_DATE + 365, 0,      TRUE),
  ('TRAIL20',    20, CURRENT_DATE,       0,      TRUE),
  ('SUMMIT25',   25, CURRENT_DATE - 1,   0,      TRUE),   -- expired yesterday
  ('BIGSPEND15', 15, CURRENT_DATE + 90,  20000,  TRUE),   -- $200 minimum
  ('RETIRED50',  50, CURRENT_DATE + 365, 0,      FALSE);  -- deactivated

-- ---------------------------------------------------------------- history
-- Orders for the first 60 customers, so order history and the admin portal
-- have something to show on a fresh install.
INSERT INTO orders (customer_id, status, subtotal_cents, discount_cents,
                    total_cents, discount_code, payment_ref, created_at)
SELECT
    c.id,
    (ARRAY['placed','shipped','delivered','cancelled'])[1 + (c.id % 4)],
    s.subtotal,
    0,
    s.subtotal,
    NULL,
    'seed-pay-' || c.id,
    CURRENT_TIMESTAMP - ((c.id % 90) || ' days')::interval
FROM customers c
CROSS JOIN LATERAL (SELECT 4999 + ((c.id * 271) % 40000) AS subtotal) s
WHERE c.id <= 60;

-- unit_price × quantity MUST equal the order's subtotal. It did not: the
-- unit price was set to the whole subtotal and then multiplied by 1–3, so
-- forty of the sixty seeded orders failed the most natural assertion anybody
-- writes against GET /api/orders/{id} — for a reason in this file rather than
-- in the answer key. Quantity is derived from the subtotal so the arithmetic
-- closes exactly, with no rounding left over.
INSERT INTO order_items (order_id, product_id, quantity, unit_price_cents)
SELECT o.id,
       1 + ((o.id * 17) % 40000),
       q.quantity,
       o.subtotal_cents / q.quantity
FROM orders o
CROSS JOIN LATERAL (SELECT 1 + (o.id % 3) AS quantity) q
WHERE o.subtotal_cents % (1 + (o.id % 3)) = 0
UNION ALL
-- subtotals that do not divide evenly get a single line item, so the
-- reconciliation holds for every order rather than most of them.
SELECT o.id, 1 + ((o.id * 17) % 40000), 1, o.subtotal_cents
FROM orders o
WHERE o.subtotal_cents % (1 + (o.id % 3)) <> 0;

ANALYZE products;
ANALYZE orders;
ANALYZE order_items;
