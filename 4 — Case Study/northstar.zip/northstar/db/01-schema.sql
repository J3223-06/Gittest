-- NorthStar Outfitters — schema.
--
-- Deliberately ordinary. The teaching value is in what the schema does NOT
-- enforce, which is where several planted defects live: there is no stock
-- constraint on cart_items, no uniqueness on an order's idempotency key, and
-- no foreign key from orders back to the cart that produced them.
--
-- Where a constraint IS present, it is present because a learner needs to see
-- the difference between "the database refused it" and "the application
-- forgot to check".

DROP TABLE IF EXISTS email_log, order_items, orders, cart_items, carts,
                     discount_codes, products, customers, admin_users CASCADE;

-- ---------------------------------------------------------------- people
CREATE TABLE customers (
    id            SERIAL PRIMARY KEY,
    email         TEXT NOT NULL UNIQUE,
    -- called out in the contract; do not copy it into anything real.
    password_hash TEXT NOT NULL,
    full_name     TEXT NOT NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE admin_users (
    id            SERIAL PRIMARY KEY,
    email         TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    full_name     TEXT NOT NULL
);

-- ---------------------------------------------------------------- catalogue
CREATE TABLE products (
    id          SERIAL PRIMARY KEY,
    sku         TEXT NOT NULL UNIQUE,
    name        TEXT NOT NULL,
    category    TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    -- Money as integer cents. The program's Appendix B argues this at length
-- in its money section; float money is the worked example there.
    price_cents INTEGER NOT NULL,
    stock       INTEGER NOT NULL DEFAULT 0,
    active      BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- with catalogue size, and only a load test makes it visible.

-- ---------------------------------------------------------------- cart
CREATE TABLE carts (
    id          SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES customers(id),
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE cart_items (
    id         SERIAL PRIMARY KEY,
    cart_id    INTEGER NOT NULL REFERENCES carts(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id),
    -- is the only thing standing between a customer and a cart of -3 tents.
    quantity   INTEGER NOT NULL
);

-- ---------------------------------------------------------------- discounts
CREATE TABLE discount_codes (
    code               TEXT PRIMARY KEY,
    percent_off        INTEGER NOT NULL,
    -- "expires 2026-09-30" is ambiguous about the 30th itself, and the
    -- application resolves it the wrong way.
    expires_on         DATE NOT NULL,
    min_subtotal_cents INTEGER NOT NULL DEFAULT 0,
    active             BOOLEAN NOT NULL DEFAULT TRUE
);

-- ---------------------------------------------------------------- orders
CREATE TABLE orders (
    id              SERIAL PRIMARY KEY,
    customer_id     INTEGER NOT NULL REFERENCES customers(id),
    status          TEXT NOT NULL DEFAULT 'placed',
    subtotal_cents  INTEGER NOT NULL,
    discount_cents  INTEGER NOT NULL DEFAULT 0,
    total_cents     INTEGER NOT NULL,
    discount_code   TEXT,
    payment_ref     TEXT,
    -- orders, and nothing in the schema objects.
    idempotency_key TEXT,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE order_items (
    id               SERIAL PRIMARY KEY,
    order_id         INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id       INTEGER NOT NULL REFERENCES products(id),
    quantity         INTEGER NOT NULL,
    unit_price_cents INTEGER NOT NULL
);

-- ---------------------------------------------------------------- email
-- Not a real mail server. A table, so that "did the customer get a
-- confirmation?" is an assertion a test can make rather than a thing a human
-- checks in an inbox. Making notifications testable at all is half the lesson.
CREATE TABLE email_log (
    id         SERIAL PRIMARY KEY,
    to_address TEXT NOT NULL,
    subject    TEXT NOT NULL,
    body       TEXT NOT NULL,
    order_id   INTEGER,
    sent_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_cart_items_cart ON cart_items(cart_id);
CREATE INDEX idx_order_items_order ON order_items(order_id);
