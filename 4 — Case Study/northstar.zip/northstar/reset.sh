#!/usr/bin/env bash
# Reset NorthStar to its teaching state. Run this at the start of every
# teaching day, not only between cohorts.
#
# The discount-code dates are the reason. TRAIL20 is seeded at CURRENT_DATE so
# accepts — is always live. CURRENT_DATE is fixed at load time, so a database
# discount exercise is dead, and verify_defects.py goes red for a reason that
# has nothing to do with the code.
#
# The contract used to call this "permanently reproducible". It is reproducible
# for one day, and this script is what makes that survivable.
set -euo pipefail
cd "$(dirname "$0")"

: "${PGHOST:=localhost}" "${PGUSER:=northstar}" "${PGDATABASE:=northstar}"
export PGPASSWORD="${PGPASSWORD:-northstar}"

if [[ "${1:-}" == "--dates-only" ]]; then
  # Cheap path: keep the data, move the boundary back to today. Use this
  # between sessions on the same install.
  psql -h "$PGHOST" -U "$PGUSER" -d "$PGDATABASE" -q <<'SQL'
UPDATE discount_codes SET expires_on = CURRENT_DATE     WHERE code = 'TRAIL20';
UPDATE discount_codes SET expires_on = CURRENT_DATE - 1 WHERE code = 'SUMMIT25';
UPDATE discount_codes SET expires_on = CURRENT_DATE + 90 WHERE code = 'BIGSPEND15';
UPDATE discount_codes SET expires_on = CURRENT_DATE + 365
  WHERE code IN ('WELCOME10', 'RETIRED50');
SQL
  echo "discount boundaries moved to today"
  exit 0
fi

psql -h "$PGHOST" -U "$PGUSER" -d "$PGDATABASE" -q -f db/01-schema.sql
psql -h "$PGHOST" -U "$PGUSER" -d "$PGDATABASE" -q -f db/02-seed.sql 2>&1 \
  | grep -v 'permission denied to analyze' || true
psql -h "$PGHOST" -U "$PGUSER" -d "$PGDATABASE" -tAc \
  "select (select count(*) from products)||' products, '
        ||(select count(*) from orders)||' orders, '
        ||(select count(*) from email_log)||' emails, TRAIL20 expires '
        ||(select expires_on from discount_codes where code='TRAIL20')
        ||' (today is '||current_date||')';"
