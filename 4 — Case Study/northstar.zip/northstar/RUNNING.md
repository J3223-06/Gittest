# NorthStar Outfitters — getting it running

A small e-commerce platform: a catalogue, a cart, discount codes, checkout and
an order history. It is deliberately imperfect, and finding out how is the work.

**It needs PostgreSQL.** That is the whole of the setup difficulty, and it is
where every "it does not start" begins.

---

## Prerequisites

| Need | Check with | If missing |
|---|---|---|
| **PostgreSQL 14+**, running | `pg_isready` | macOS: `brew install postgresql@16 && brew services start postgresql@16` · Debian/Ubuntu: `sudo apt install postgresql` then `sudo service postgresql start` · Windows: use the installer, or run Postgres in Docker (below) |
| **`psql`** on your path | `psql --version` | Ships with PostgreSQL; on Linux it may be in `postgresql-client` |
| **Python 3.10+** | `python3 --version` | |
| The Python packages | — | `pip install fastapi uvicorn psycopg2-binary pydantic` |

**Postgres in Docker**, if you would rather not install it:

```bash
docker run -d --name northstar-db -p 5432:5432 \
  -e POSTGRES_USER=northstar \
  -e POSTGRES_PASSWORD=northstar \
  -e POSTGRES_DB=northstar \
  postgres:16
```

That gives you exactly the user, password and database the default connection
string expects.

---

## First run

```bash
cd northstar
./reset.sh          # creates the schema and loads the seed data
./run.sh            # starts it on http://127.0.0.1:8090
```

`run.sh` prints one line when it is up:

```
NorthStar up on :8090  release=2.6  locators=v1  payment_key=unset
```

Open <http://127.0.0.1:8090> and click around before you test anything. Ten
minutes of using a system as a person is worth more than an hour of reading it.

Stop it with `./run.sh stop`.

---

## The switches

`run.sh` takes up to three arguments. They are not options — **they are the
exercises.** Two phases of the case study depend on them.

| Command | What you get |
|---|---|
| `./run.sh` | Release 2.6, v1 locators. The normal build |
| `./run.sh 2.7` | Release 2.7 in production configuration |
| `./run.sh 2.7 v1 staging` | Release 2.7 with the staging configuration |
| `./run.sh 2.6 v2` | Release 2.6 with the v2 locators |
| `./run.sh stop` | Stop whatever is running |

Your workbook says when to use each. Running them out of order spoils the
exercise rather than breaking anything — the point of each is the thing you
notice, and you only notice it once.

---

## Run this at the start of every session

```bash
./reset.sh --dates-only
```

Some of the seeded data is date-sensitive: it is written relative to the day it
was loaded, so a database seeded on Monday describes a different situation by
Wednesday. `run.sh` re-stamps the dates on every start, so in normal use you
never think about it. Run the command above if you have been away from it for a
few days and something that used to behave one way now behaves another.

`./reset.sh` with no arguments is the full reset — schema, data and dates. Use it
if you have changed the data while testing and want a clean start. **It discards
everything in the database**, which is fine: nothing here is yours to keep.

---

## When it does not start

| What you see | What it means | What to do |
|---|---|---|
| `did not become healthy` | It started but could not reach the database | Is Postgres running? `pg_isready`. Then `./reset.sh` |
| `/health` returns 503 | Same — the process is up, the database is not answering | As above |
| `port 8090 is answering /health as release '…'` | Something else is already on that port | `./run.sh stop`, or use another port: `PORT=8091 ./run.sh` |
| `psql: command not found` | The client is not on your path | Install `postgresql-client`, or use the Docker option above and run `psql` inside the container |
| `FATAL: role "northstar" does not exist` | The database user has not been created | `createuser -s northstar` then `createdb -O northstar northstar`, or use the Docker option, which creates both |

The log is at `/tmp/northstar-8090.log` and the useful line is rarely the first
one. Read all of it — which is the same advice §2 of the Self-Paced Guide gives
about every error, and it is advice because it keeps being right.

---

## What is in here

```
app/app.py            the application — one file, readable in an afternoon
db/01-schema.sql      the schema
db/02-seed.sql        the seed data
run.sh                start, stop, and the release switches
reset.sh              rebuild the database, or just re-stamp the dates
teaching/learner/     your workbook, the manual test cases, the user stories
```

Start with `teaching/learner/WORKBOOK.md`.

> **Localhost only.** This is a teaching fixture with known weaknesses. It binds
> to `127.0.0.1` on purpose. Do not deploy it anywhere anyone else can reach.
