---
title: "NorthStar Outfitters — User Stories for Phase 3"
subtitle: "Case Study · as the product owner wrote them"
---

# Read this first

**These are six stories as a product owner actually writes them**, not as a
textbook prints them. They are short, they are reasonable, and **four of them
contain an ambiguity that cannot be resolved by reading harder.**

That is the point of the phase. Week 1 §1.9.3 says the decision-table row nobody
can confidently fill in is a requirements gap rather than a testing problem.
These stories are where you meet that in something resembling the wild.

**Your job is not to guess the missing answer.** It is to produce acceptance
criteria for what *is* decided, and a marked list of *questions for the product
owner* for what is not. A learner who fills every gap with a confident guess has
done the more comfortable thing and the less useful one.

> **One of the four ambiguities is worth real money and is already live in the
> code.** You will not be told which. If you find it from the story rather than
> from the implementation, you have done the phase properly — the implementation
> has silently chosen one reading, and nobody has told the person whose budget it
> comes out of.

---

## US-1 — Browse and search the catalogue

> **As a** customer
> **I want to** search the catalogue by name
> **So that** I can find equipment without scrolling the whole range.

**Notes from the PO:** "It should be fast. Customers complain that search is
slow when we have a lot of stock in."

**Acceptance, as given:**

- Searching a word that appears in a product name returns that product
- Searching something that matches nothing shows an empty result, not an error
- Search is not case-sensitive

---

## US-2 — Add items to a cart

> **As a** customer
> **I want to** add equipment to a cart
> **So that** I can buy several things at once.

**Acceptance, as given:**

- Adding an item puts it in my cart with the quantity I chose
- The cart shows a running subtotal
- I can remove an item
- **I cannot order more than we have in stock**

---

## US-3 — Use a discount code

> **As a** customer
> **I want to** enter a discount code at checkout
> **So that** I get the advertised price.

**Notes from the PO:** "Marketing runs codes with an end date. `TRAIL20` is our
spring campaign, 20% off, and it **expires 31 May**."

**Acceptance, as given:**

- A valid code reduces the total by its percentage
- An expired code is refused, and the customer is told why
- A code below its minimum spend is refused
- A code we have turned off is refused

---

## US-4 — Check out

> **As a** customer
> **I want to** pay for what is in my cart
> **So that** the order is placed and I get a confirmation.

**Acceptance, as given:**

- Checking out an empty cart is refused
- A successful checkout creates an order and charges the card once
- The customer gets a confirmation email
- The order appears in the customer's history

---

## US-5 — See my order history

> **As a** customer
> **I want to** see my past orders
> **So that** I can check what I bought and when.

**Acceptance, as given:**

- I see my orders, newest first
- Each shows the date, the items, and what I paid

---

## US-6 — Manage the catalogue

> **As an** administrator
> **I want to** add and edit products
> **So that** the catalogue stays current.

**Acceptance, as given:**

- I can add a product with a name, a price and a stock level
- I can edit an existing product
- Changes appear on the storefront

---
