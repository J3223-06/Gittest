---
title: "NorthStar Outfitters — Case Study Workbook"
subtitle: "Project Work Automation, Clean Code & Software Quality Engineering — Canadian Edition 2025"
---

# Before you start

You have been brought into NorthStar Outfitters as an automation engineer.

**The situation, in their words:** regression testing is manual and takes three
days. Releases happen twice a week. Defects are escaping to production at an
increasing rate. The QA team is four people and engineering will not stop
shipping while testing catches up.

**What you have been given:** a running system, and the twenty-eight test cases
the QA team currently runs by hand.

**What nobody has given you:** a list of what is wrong with it. Finding that out
is the job.

```bash
createdb northstar && psql northstar -f db/01-schema.sql -f db/02-seed.sql
./run.sh                     # the system as it stands
./run.sh stop
```

> **Log in as `reviewer@northstar.test` / `northstar`.** Every seeded customer
> uses the same password, which is itself worth a thought before Phase 4.

---

# Phase 1 — What to automate

Read `MANUAL-TEST-CASES.md`, then read the system. **Do not start writing tests.**

## 1.1 Score the suite

For each of the twenty-eight cases, answer Week 1 §1.11's four questions and
assign a layer using §3.8's rule — *the lowest layer that could tell you it is
broken.*

| Case | Runs how often | Manual cost | Build + keep | Stable? | Layer | Automate? |
|---|---|---|---|---|---|---|
| M-01 | | | | | | |
| M-02 | | | | | | |
| … | | | | | | |

*(The full twenty-eight-row version is in `docs/automation-plan.md` — this is the
shape.)*

## 1.2 The three you are not automating

Name three cases you would leave manual, and for each write **the sentence you
would say to the QA lead.** Not the reason — the sentence.

1. ______________________________________________
2. ______________________________________________
3. ______________________________________________

> A learner who cannot produce these three sentences has not made a decision.
> "Automate everything" is the answer of somebody who has not counted the cost
> of keeping it.

## 1.3 The cases the interface cannot express

At least one case in that document **cannot be executed through the user
interface at all** — not because it is hard, but because the interface gives you
no way to ask the question.

Find them. For each, write what a tester clicking through the application would
have to do, and why they cannot:

> ______________________________________________

## 1.4 What is missing

Take three cases and ask of each: *what could be broken here that this case
would not notice?*

| Case | What it would not notice |
|---|---|
| | |
| | |
| | |

**Deliverable:** `docs/automation-plan.md`.

---

# Phase 2 — The API suite

Build the API rows of your plan, running in CI.

## 2.1 Before you write a test, write its oracle

For your first five tests, fill this in **before** the assertion exists. Week 1
§1.10's table: specification · independent calculation · metamorphic relation ·
invariant · cross-check · snapshot · judgement.

| Test | Expected value | Where the value came from | Oracle type |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |

> **If more than one says "I ran it and copied the output", stop.** You are
> pinning behaviour, not testing it — and on a system you have been told
> contains defects, pinning is the one thing you must not do by accident.

## 2.2 Findings

One row per defect. A report somebody else cannot reproduce from the report
alone is not finished.

| # | What is wrong | Where | How to reproduce | What it costs the business |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |

## 2.3 Count

How many did your API suite find? ______

**Before you look at anything else, answer this:** which of your Phase 1 layer
decisions would you now change, and why? This question is worth more than the
count.

> ______________________________________________

---

# Phase 3 — The stories

Read `USER-STORIES.md`. Six stories from the product owner.

## 3.1 Criteria

For each story, write acceptance criteria in three-clause form (Week 1 §1.8) and
map each to a layer.

## 3.2 The questions you cannot answer

**Some of these stories cannot be turned into criteria without asking somebody.**
Do not guess. List the questions, phrased as you would send them to the product
owner — in business language, not in engineering language.

| Story | The question | Why it cannot be decided from the story |
|---|---|---|
| | | |
| | | |
| | | |
| | | |

> **At least one of these questions is already costing NorthStar money.** You
> will not be told which. If you find it from the story rather than from the
> code, you have done this phase properly.

**Deliverable:** `docs/acceptance-criteria.md`, with the questions list marked.

---

# Phase 4 — The other three layers

## 4.1 Load

| | Value |
|---|---|
| Catalogue size tested at | |
| p95 **before** | |
| The one thing you changed | |
| p95 **after** | |

**Both numbers, or it is not an experiment.** A "we made it faster" with one
measurement is a claim.

## 4.2 Security

What did the scanner find, and what did you do with each finding? Triage means
deciding, not listing.

| Finding | Severity | Decision | Why |
|---|---|---|---|
| | | | |
| | | | |

## 4.3 Accessibility

Run axe against `/login` and `/products`.

| Page | Violation | Rule | Impact |
|---|---|---|---|
| | | | |
| | | | |

## 4.4 The one no tool found

By the end of this phase you have run a load test, a security scanner and an
accessibility scanner, on top of an API suite and a UI suite.

**There is something wrong with this system that none of them can find**, and it
is not exotic — it is in a function you have probably already read.

What is it, and what would have caught it?

> ______________________________________________

---

# Phase 5 — The incident

*Your instructor will change something. You will not be told what.*

Fill this in during the incident, not afterwards:

| | |
|---|---|
| What did you observe first? | |
| What did `/health` say? | |
| What did the pipeline say? | |
| What did staging say? | |
| How long until you knew what was wrong? | |

**The question:** which test, at which layer, running against **which
environment**, would have caught this before a customer did?

> ______________________________________________

> The answer is not "a better test". Write down which environment it runs
> against, because that is the part that matters and it is the part your suite
> currently has no version of.

---

# Phase 6 — The rename

*Your instructor will change something again.*

| | |
|---|---|
| How many of your tests went red? | |
| How many things actually broke for a customer? | |
| How long did the fix take? | |

**The question this phase exists for:** what should your locator strategy have
been, and **who owns the attribute?**

> ______________________________________________

> A suite that goes red when nothing broke is the commonest reason teams stop
> trusting automation. This is the cheapest possible version of that experience.

---

# Closing out

## The recommendation

Four people. Three-day manual regression. Two releases a week.

Write one page **to the QA lead** — a person, not a document. It must name:

- **The first thing they should build**, and why that first
- **What it costs** — build and keep, in days
- **Something they should stop doing**

> "Automate everything" is not a recommendation. Neither is a list of tools.

## The retirement rule

Under what conditions may the next person delete one of the tests you just
wrote? (Week 1 §1.11.4.)

> ______________________________________________

## The two defence questions

1. **Which of the twenty-eight did you decide not to automate, and what did you
   say to the QA lead?**

   > ______________________________________________

2. **Name a defect no layer you built could have caught, and say what would
   catch it.**

   > ______________________________________________

> If your answer to the second is "my suite catches everything", go back to
> Phase 4.4. A pipeline that is green proves that nothing you thought to check
> is broken — and this week exists to show you the distance between that
> sentence and "nothing is broken".
