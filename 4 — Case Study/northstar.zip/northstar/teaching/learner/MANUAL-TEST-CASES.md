---
title: "NorthStar Outfitters — Manual Test Cases"
subtitle: "Case Study · Project Work Automation, Clean Code & Software Quality Engineering — Canadian Edition 2025"
---

# What this is, and who it is for

**Twenty-eight manual test cases against NorthStar Outfitters**, handed over by the QA team who run them, in the form a
manual tester already writes: id, preconditions, steps, expected result.

It exists for three reasons and they are worth separating.

**One — it is the bridge.** Week 1 §1.8 makes the point that an acceptance
criterion in three clauses is *already shaped like the test it will become*.
This document is the other end of that bridge: cases a manual tester recognises
on sight, each annotated with the layer it should be automated at and the
technique that produced it. A learner moving from manual testing starts here,
where they are the expert, rather than at a framework.

**Two — it is the Phase 1 input.** The case-study week opens with these cases
and a running system, and asks: *which of these do you automate, at what layer,
and which do you leave alone?* That is Week 1 §1.11's decision applied to
somebody else's suite, which is a great deal easier than applying it to your own.

**Three — it is honest about having limits.** These cases were written by
somebody who knows this domain and has run them many times, and they still do
not cover everything that is wrong with this system. Part of Phase 1 is working
out where the gaps are — not by being told, but by asking of each case *what
could be broken that this would not notice?*



## How to read the annotations

| Column | Means |
|---|---|
| **Technique** | Which of Week 1 §1.9's techniques produced this case — partitioning, boundary, decision table, state transition, error guessing |
| **Layer** | Where it should be automated, using Week 1 §3.8's decision rule: the lowest layer that could tell you it is broken |
| **Oracle** | Where the expected result comes from (Week 1 §1.10). `spec` is strongest; `judgement` is weakest and is flagged |

---

# 1 — Catalogue and search

| # | Case | Technique | Layer | Oracle |
|---|---|---|---|---|
| **M-01** | **Catalogue loads with products.** *Given* a seeded database, *when* I open `/products`, *then* a list of products is shown, each with a name and a price. | partitioning (the non-empty case) | API | spec |
| **M-02** | **Search finds a known product.** *Given* the catalogue contains "Alpine", *when* I search `alpine`, *then* only matching products are listed. | partitioning | API | spec |
| **M-03** | **Search with no matches.** *When* I search `zzzznothing`, *then* an empty result is shown and **not** an error. | boundary (the empty result) | API | spec |
| **M-04** | **Search is case-insensitive.** *When* I search `ALPINE` and `alpine`, *then* both return the same products. | partitioning | API | spec |
| **M-05** | **Search under load.** *Given* a catalogue of 40,000 products, *when* I search a term matching few rows, *then* the result returns in under a second. | error guessing | **load test** | judgement — the "under a second" is a guess until Week 3 sets a threshold from a baseline |
| **M-06** | **A product page shows stock.** *When* I open a product, *then* its available stock is shown. | partitioning | API | spec |
| **M-07** | **A product id that does not exist.** *When* I request product `999999`, *then* I get a not-found response, not a server error. | boundary | API | spec |

---

# 2 — Cart

| # | Case | Technique | Layer | Oracle |
|---|---|---|---|---|
| **M-08** | **Add one item to an empty cart.** *Then* the cart shows one line and the correct subtotal. | boundary (the empty cart) | API | spec |
| **M-09** | **Add the same product twice.** *Then* the cart reflects both additions and the subtotal is the sum. | partitioning | API | spec |
| **M-10** | **Remove the only item.** *Then* the cart is empty and the subtotal is zero, not blank and not an error. | boundary (back to empty) | API | spec |
| **M-11** | **order more than the stock on hand.** *Given* a product with 3 in stock, *when* I add 99, *then* the request should be refused. | boundary (stock + 1) | API | spec |
| **M-12** | **order a negative quantity.** *When* I add `-5`, *then* it should be refused. | boundary (below zero) | API | spec |
| **M-13** | **order zero.** *When* I add `0`, *then* it should be refused. | boundary (zero) | API | spec |
| **M-14** | **Cart survives a page refresh.** *Then* the same lines are shown. | state transition | E2E | spec |

---

# 3 — Discount codes

The decision table that produced this section. Three conditions — is the code
active, is it within its expiry, is the subtotal above its minimum — so eight
combinations, written out before being collapsed.

| # | Active | In date | Above minimum | Expected | Case |
|---|---|---|---|---|---|
| 1 | Yes | Yes | Yes | Applied | M-15 |
| 2 | Yes | Yes | No | Refused — below minimum | M-19 |
| 3 | Yes | **On the expiry date** | Yes | **Refused — the code is dated *through* the day before** | **M-16** |
| 4 | Yes | No (expired) | Yes | Refused — expired | M-17 |
| 5 | No (deactivated) | Yes | Yes | Refused — not active | M-18 |
| 6 | No | Yes | No | Refused — either reason is sufficient | — |
| 7 | No | No | Yes | Refused | — |
| 8 | No | No | No | Refused | — |

Rows 6 to 8 are collapsed: once any single condition refuses the code, the
others cannot change the outcome. **Collapsing happens after the table is
written, never instead of writing it** — row 3 is the whole point of this
section and it is the row that is easiest to leave out.

| # | Case | Technique | Layer | Oracle |
|---|---|---|---|---|
| **M-15** | **A valid code applies.** *Given* `WELCOME10` and a $100 subtotal, *then* $10 comes off. | decision table row 1 | unit or API | spec |
| **M-16** | **a code on its expiry date.** *Given* `TRAIL20`, whose `expires_on` is **today**, *when* I apply it, *then* it should be refused. | **boundary — the value AT the edge** | **unit** | spec |
| **M-17** | **A code that expired yesterday is refused.** `SUMMIT25`. | boundary (one past the edge) | unit or API | spec |
| **M-18** | **A deactivated code is refused.** `RETIRED50`, which is in date and has no minimum. | decision table row 5 | unit or API | spec |
| **M-19** | **A code below its minimum spend is refused.** `BIGSPEND15` needs $200. | decision table row 2 | unit or API | spec |
| **M-20** | **A code exactly at its minimum is accepted.** `BIGSPEND15` at exactly $200.00. | **boundary — AT the minimum** | unit | spec |
| **M-21** | **A code that does not exist is refused.** `NOTACODE`. | error guessing | API | spec |

---

# 4 — Checkout and orders

| # | Case | Technique | Layer | Oracle |
|---|---|---|---|---|
| **M-22** | **Checkout an empty cart.** *Then* it is refused. | boundary (empty) | API | spec |
| **M-23** | **A successful checkout creates an order.** *Then* the order appears in my history with the right total. | state transition (cart → order) | API | spec |
| **M-24** | **submit checkout twice.** *When* the same request is sent again, *then* one order should exist. | **state transition — the repeated transition** | **API, with a repeated key** | spec |
| **M-25** | **read another customer's order.** *Given* I am customer 401, *when* I request an order belonging to customer 12, *then* it should be refused. | error guessing | **API** | spec |
| **M-26** | **fifty wrong passwords in a row.** *Then* the account or the source should be throttled. | error guessing | **API** | judgement — no rate limit is specified, which is itself the finding |

> **M-25 is the second case that cannot be done through the interface**, and for
> a subtler reason than M-11's. The UI never renders a link to another
> customer's order, so a tester clicking through the application has no path to
> the request at all. The defect is not hidden by the interface; the interface
> makes it *unreachable*. Only a tool that can construct the request finds it.

---

# 5 — Accessibility and presentation

| # | Case | Technique | Layer | Oracle |
|---|---|---|---|---|
| **M-27** | **reach the login form with the keyboard only.** *When* I tab to the password field, *then* a screen reader should announce what it is for. | error guessing | **axe** | WCAG 1.3.1/4.1.2 |
| **M-28** | **read the muted text.** *Then* body text should meet 4.5:1 contrast. | error guessing | **axe / a contrast tool** | WCAG 1.4.3 |

---

---

# What you are being asked

These are the cases the existing QA team runs by hand. It takes them three days.

**You are not being asked to automate all of them.** Phase 1 asks you to decide:
which of these should be automated, at which layer, and which should stay
manual — and to say what you would tell the QA lead about the ones you are not
automating.

Some of these cases pass today. Some do not. Some **cannot be executed through
the interface at all**, and finding those is part of the phase.
