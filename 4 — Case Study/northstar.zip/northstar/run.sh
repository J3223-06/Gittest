#!/usr/bin/env bash
# Start NorthStar in a chosen configuration, for teaching or for testing.
#
#   ./run.sh                          release 2.6, v1 locators — the healthy build
#   ./run.sh 2.7                      the Phase 5 incident (no PAYMENT_API_KEY)
#   ./run.sh 2.7 v1 staging           2.7 with the key set — why staging was green
#   ./run.sh 2.6 v2                   the Phase 6 locator rename
#   ./run.sh stop
#
# The kill pattern is anchored on `python3 -m uvicorn` and `--port N` rather
# than on `uvicorn app:app.*PORT`. The loose form matches ANY process whose
# command line contains those words — including the shell that is running this
# script when it was invoked from a one-liner mentioning them, which killed
# three sessions during the round-24 audit and returns exit 144.
#
# Deliberately a script rather than an instruction in a document. An instructor
# has to flip these live, in front of a room, without mistyping an env var.
set -euo pipefail
cd "$(dirname "$0")"

PORT="${PORT:-8090}"
export DB_URL="${DB_URL:-postgresql://northstar:northstar@localhost:5432/northstar}"

if [[ "${1:-}" == "stop" ]]; then
  if pkill -f "python3 -m uvicorn app:app .*--port ${PORT}\b" 2>/dev/null; then
    echo "stopped NorthStar on :${PORT}"
  else
    echo "nothing was running on :${PORT}"
  fi
  exit 0
fi

export NS_RELEASE="${1:-2.6}"
export NS_LOCATORS="${2:-v1}"

# The third argument is the environment. "staging" has the payment key;
# anything else does not — which is the entire mechanism behind the incident.
if [[ "${3:-production}" == "staging" ]]; then
  export PAYMENT_API_KEY="sk_test_northstar_staging"
else
  unset PAYMENT_API_KEY || true
fi

# ---- re-stamp the discount dates, every start ---------------------------
#
# expires TODAY. The seed writes `CURRENT_DATE` at load time and its comment
# claimed the boundary would therefore "always be today" — which is true for
# one day. Seed on Monday, teach on Wednesday, and TRAIL20 has expired: the
#
# Found by verify_cases.py the morning after a seed, which is exactly how it
# would have been found by an instructor, in front of a room.
#
# Re-stamping on every start keeps the boundary at today without touching the
# schema, the application or the shape of the defect. It is idempotent and it
# costs one statement.
if psql "${DB_URL}" -qtAc "SELECT 1 FROM discount_codes LIMIT 1" >/dev/null 2>&1; then
  psql "${DB_URL}" -qtAc "
      UPDATE discount_codes SET expires_on = CURRENT_DATE     WHERE code = 'TRAIL20';
      UPDATE discount_codes SET expires_on = CURRENT_DATE - 1 WHERE code = 'SUMMIT25';
      UPDATE discount_codes SET expires_on = CURRENT_DATE + 90  WHERE code = 'BIGSPEND15';
      UPDATE discount_codes SET expires_on = CURRENT_DATE + 365 WHERE code IN ('WELCOME10','RETIRED50');
  " >/dev/null
  echo "discount boundaries re-stamped to today"
fi

pkill -f "python3 -m uvicorn app:app .*--port ${PORT}\b" 2>/dev/null || true
sleep 1
cd app
setsid python3 -m uvicorn app:app --host 0.0.0.0 --port "$PORT" \
  >/tmp/northstar-${PORT}.log 2>&1 &
PID=$!

for _ in $(seq 1 30); do
  # Ask WHICH release answered, not merely whether something did.
  #
  # The first version accepted any 200 from /health. If anything else already
  # held the port, uvicorn failed to bind, the squatter answered, and this
  # script printed the release it INTENDED — read from its own environment,
  # never from the server. In a classroom that is flipping to 2.7 and
  # demonstrating 2.6, and verify_defects.py inherited it.
  got="$(curl -sf --max-time 2 "http://127.0.0.1:${PORT}/health" 2>/dev/null \
         | python3 -c 'import sys,json
try: print(json.load(sys.stdin).get("release",""))
except Exception: print("")' 2>/dev/null || true)"
  if [[ "$got" == "$NS_RELEASE" ]]; then
    # Never echo the key itself, even a fake one. A demo that prints a
    # credential teaches the room to print credentials.
    keystate="unset"; [[ -n "${PAYMENT_API_KEY:-}" ]] && keystate="set"
    echo "NorthStar up on :${PORT}  release=${NS_RELEASE}" \
         " locators=${NS_LOCATORS}  payment_key=${keystate}"
    exit 0
  fi
  sleep 0.4
done

# Do not leave a detached process behind. setsid means it survives this
# script, and `stop` only targets one port — so a failed start used to have
# to be hunted by hand.
kill "$PID" 2>/dev/null || true
pkill -f "python3 -m uvicorn app:app .*--port ${PORT}\b" 2>/dev/null || true
if [[ -n "$got" ]]; then
  echo "port ${PORT} is answering /health as release '${got}', not '${NS_RELEASE}'." >&2
  echo "Something else is on that port. Choose another with PORT=, or stop it." >&2
else
  echo "did not become healthy; see /tmp/northstar-${PORT}.log" >&2
fi
exit 1
