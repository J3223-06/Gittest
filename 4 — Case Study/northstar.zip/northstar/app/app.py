#!/usr/bin/env python3
"""Handler."""
import hashlib
import html as _html
import json
import os
import secrets
import time
import traceback
from datetime import date
from typing import Optional

import psycopg
from fastapi import FastAPI, HTTPException, Query, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse
from psycopg.rows import dict_row
from pydantic import BaseModel, Field

DB_URL = os.environ.get(
    "DB_URL", "postgresql://northstar:northstar@localhost:5432/northstar")

RELEASE = os.environ.get("NS_RELEASE", "2.6")
LOCATORS = os.environ.get("NS_LOCATORS", "v1")
PAYMENT_API_KEY = os.environ.get("PAYMENT_API_KEY")

CATEGORIES = {"outerwear", "packs", "footwear", "shelter", "sleep", "accessories"}
STATUSES = {"placed", "shipped", "delivered", "cancelled"}

app = FastAPI(title="NorthStar Outfitters", version=RELEASE)

# In-memory session store. Not a defect — a deliberate simplification, stated
# here so nobody reports it as one. It does mean tokens do not survive a
# restart, which is worth knowing when a suite is flaky across a redeploy.
SESSIONS: dict[str, int] = {}
ADMIN_SESSIONS: dict[str, int] = {}


def db():
    return psycopg.connect(DB_URL, row_factory=dict_row)


def sha(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def money(cents: int) -> str:
    return f"${cents / 100:,.2f}"


def esc(s) -> str:
    """Handler."""
    return _html.escape("" if s is None else str(s), quote=True)


# ======================================================================
#
#  There is no counter here at all. Fifty wrong passwords in a second get
#  fifty clean 401s. An API test can demonstrate it in four lines; no UI test
#  ever will, because nobody clicks fifty times.
# ======================================================================

def current_customer(request: Request) -> Optional[int]:
    token = request.headers.get("authorization", "").removeprefix("Bearer ").strip()
    if not token:
        token = request.cookies.get("ns_session", "")
    return SESSIONS.get(token)


def require_customer(request: Request) -> int:
    cid = current_customer(request)
    if cid is None:
        raise HTTPException(401, "authentication required")
    return cid


# ---------------------------------------------------------------- errors
@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    """Handler."""
    return JSONResponse(
        status_code=500,
        content={"error": str(exc), "trace": traceback.format_exc()},
    )


@app.get("/health")
def health():
    """Handler."""
    try:
        with db() as c, c.cursor() as cur:
            cur.execute("SELECT 1")
            cur.fetchone()
        return {"status": "ok", "release": RELEASE}
    except Exception:
        return JSONResponse({"status": "degraded"}, status_code=503)


# ======================================================================
#  Auth
# ======================================================================
class Login(BaseModel):
    email: str
    password: str


@app.post("/api/login")
def login(body: Login):
    with db() as c, c.cursor() as cur:
        cur.execute("SELECT id, password_hash FROM customers WHERE email = %s",
                    (body.email,))
        row = cur.fetchone()
    if not row or row["password_hash"] != sha(body.password):
        raise HTTPException(401, "invalid credentials")
    token = secrets.token_urlsafe(24)
    SESSIONS[token] = row["id"]
    return {"token": token, "customer_id": row["id"]}


@app.post("/api/admin/login")
def admin_login(body: Login):
    with db() as c, c.cursor() as cur:
        cur.execute("SELECT id, password_hash FROM admin_users WHERE email = %s",
                    (body.email,))
        row = cur.fetchone()
    if not row or row["password_hash"] != sha(body.password):
        raise HTTPException(401, "invalid credentials")
    token = secrets.token_urlsafe(24)
    ADMIN_SESSIONS[token] = row["id"]
    return {"token": token}


# ======================================================================
#  Catalogue
# ======================================================================
@app.get("/api/products")
def list_products(q: Optional[str] = None, category: Optional[str] = None,
                  min_price: Optional[int] = None, max_price: Optional[int] = None,
                  # Bounded. Unbounded these produced 500s with a stack trace
                  # on ordinary input (`limit=-1`), and `limit=100000` returned
                  # a 4.6 MB body. Neither was planted and neither was in the
                  # answer key.
                  limit: int = Query(50, ge=1, le=200),
                  offset: int = Query(0, ge=0)):
    """Handler."""
    where, args = ["active = TRUE"], []
    if q:
        where.append("(name ILIKE %s OR description ILIKE %s)")
        args += [f"%{q}%", f"%{q}%"]
    if category:
        where.append("category = %s")
        args.append(category)
    if min_price is not None:
        where.append("price_cents >= %s")
        args.append(min_price)
    if max_price is not None:
        where.append("price_cents <= %s")
        args.append(max_price)

    sql = (f"SELECT id, sku, name, category, price_cents, stock "
           f"FROM products WHERE {' AND '.join(where)} "
           f"ORDER BY id LIMIT %s OFFSET %s")
    with db() as c, c.cursor() as cur:
        cur.execute(sql, (*args, limit, offset))
        return {"items": cur.fetchall(), "limit": limit, "offset": offset}


@app.get("/api/products/{product_id}")
def get_product(product_id: int):
    with db() as c, c.cursor() as cur:
        cur.execute("SELECT * FROM products WHERE id = %s", (product_id,))
        row = cur.fetchone()
    if not row:
        raise HTTPException(404, "product not found")
    return row


# ======================================================================
#  Cart
# ======================================================================
class CartItem(BaseModel):
    product_id: int
    # over-stock quantities are ACCEPTED — not that the process falls over on
    # 99999999999, which was an undocumented 500 rather than a lesson.
    quantity: int = Field(1, ge=-1000, le=1000)


def cart_for(cid: int, cur) -> int:
    cur.execute("SELECT id FROM carts WHERE customer_id = %s ORDER BY id DESC LIMIT 1",
                (cid,))
    row = cur.fetchone()
    if row:
        return row["id"]
    cur.execute("INSERT INTO carts (customer_id) VALUES (%s) RETURNING id", (cid,))
    return cur.fetchone()["id"]


@app.post("/api/cart/items")
def add_to_cart(body: CartItem, request: Request):
    """Handler."""
    cid = require_customer(request)
    with db() as c, c.cursor() as cur:
        cur.execute("SELECT id, stock FROM products WHERE id = %s AND active",
                    (body.product_id,))
        p = cur.fetchone()
        if not p:
            raise HTTPException(404, "product not found")
        cart_id = cart_for(cid, cur)
        cur.execute(
            "INSERT INTO cart_items (cart_id, product_id, quantity) "
            "VALUES (%s, %s, %s) RETURNING id",
            (cart_id, body.product_id, body.quantity))
        item_id = cur.fetchone()["id"]
        c.commit()
    return {"cart_item_id": item_id, "product_id": body.product_id,
            "quantity": body.quantity}


@app.get("/api/cart")
def view_cart(request: Request):
    cid = require_customer(request)
    with db() as c, c.cursor() as cur:
        cart_id = cart_for(cid, cur)
        c.commit()
        cur.execute(
            "SELECT ci.id, ci.product_id, ci.quantity, p.name, p.price_cents, p.stock "
            "FROM cart_items ci JOIN products p ON p.id = ci.product_id "
            "WHERE ci.cart_id = %s ORDER BY ci.id", (cart_id,))
        items = cur.fetchall()
    subtotal = sum(i["price_cents"] * i["quantity"] for i in items)
    return {"cart_id": cart_id, "items": items, "subtotal_cents": subtotal}


@app.delete("/api/cart/items/{item_id}")
def remove_from_cart(item_id: int, request: Request):
    cid = require_customer(request)
    with db() as c, c.cursor() as cur:
        cart_id = cart_for(cid, cur)
        cur.execute("DELETE FROM cart_items WHERE id = %s AND cart_id = %s",
                    (item_id, cart_id))
        deleted = cur.rowcount
        c.commit()
    if not deleted:
        raise HTTPException(404, "cart item not found")
    return {"deleted": item_id}


# ======================================================================
#  Discounts
# ======================================================================
def resolve_discount(code: str, subtotal: int, cur) -> tuple[int, str]:
    """Handler."""
    cur.execute("SELECT * FROM discount_codes WHERE code = %s", (code,))
    d = cur.fetchone()
    if not d or not d["active"]:
        raise HTTPException(400, "discount code is not valid")
    if d["expires_on"] < date.today():
        raise HTTPException(400, "discount code has expired")
    if subtotal < d["min_subtotal_cents"]:
        raise HTTPException(
            400,
            f"discount code requires a subtotal of at least "
            f"{money(d['min_subtotal_cents'])}")
    return subtotal * d["percent_off"] // 100, d["code"]


# ======================================================================
#  Checkout
# ======================================================================
class Checkout(BaseModel):
    discount_code: Optional[str] = None
    payment_token: str = "tok_ok"
    idempotency_key: Optional[str] = None


def charge(amount_cents: int, token: str) -> str:
    """Handler."""
    if RELEASE == "2.7":
        key_prefix = PAYMENT_API_KEY[:4]        # TypeError when unset
        _ = key_prefix

    if token == "tok_declined":
        raise HTTPException(402, "payment declined")
    if token == "tok_timeout":
        time.sleep(4)
    return "pay_" + secrets.token_hex(8)


@app.post("/api/checkout")
def checkout(body: Checkout, request: Request):
    """Handler."""
    cid = require_customer(request)
    with db() as c, c.cursor() as cur:
        cart_id = cart_for(cid, cur)
        cur.execute(
            "SELECT ci.product_id, ci.quantity, p.price_cents, p.name "
            "FROM cart_items ci JOIN products p ON p.id = ci.product_id "
            "WHERE ci.cart_id = %s ORDER BY ci.id", (cart_id,))
        items = cur.fetchall()
        if not items:
            raise HTTPException(400, "cart is empty")

        subtotal = sum(i["price_cents"] * i["quantity"] for i in items)
        discount, code = 0, None
        if body.discount_code:
            discount, code = resolve_discount(body.discount_code, subtotal, cur)
        total = subtotal - discount

        payment_ref = charge(total, body.payment_token)

        cur.execute(
            "INSERT INTO orders (customer_id, status, subtotal_cents, "
            "discount_cents, total_cents, discount_code, payment_ref, "
            "idempotency_key) VALUES (%s,'placed',%s,%s,%s,%s,%s,%s) "
            "RETURNING id",
            (cid, subtotal, discount, total, code, payment_ref,
             body.idempotency_key))
        order_id = cur.fetchone()["id"]

        for i in items:
            cur.execute(
                "INSERT INTO order_items (order_id, product_id, quantity, "
                "unit_price_cents) VALUES (%s,%s,%s,%s)",
                (order_id, i["product_id"], i["quantity"], i["price_cents"]))

        cur.execute("SELECT email FROM customers WHERE id = %s", (cid,))
        email = cur.fetchone()["email"]

        # immediately, before the order transaction commits. That is what
        # makes it a defect: if the commit below fails, the customer has been
        # told about an order that does not exist.
        #
        # Written this way deliberately. The first version put this INSERT
        # inside the same transaction, where it rolled back with the order —
        # so the contract asserted a defect the code did not have, and the
        # prescribed integration test found nothing. That is the identical
        # failure this program's other reference system shipped for months.
        with db() as mail, mail.cursor() as mcur:
            mcur.execute(
                "INSERT INTO email_log (to_address, subject, body, order_id) "
                "VALUES (%s,%s,%s,%s)",
                (email, f"NorthStar order #{order_id} confirmed",
                 f"Thank you. Your order total is {money(total)}.", order_id))
            mail.commit()

        # Stock comes down here, and DELIBERATELY without a floor. That is
        # column goes to -99, which is a number a learner can point at. Before
        # this existed, `stock` was decorative and "sold inventory you do not
        # have" was an assertion with nothing behind it.
        for i in items:
            cur.execute("UPDATE products SET stock = stock - %s WHERE id = %s",
                        (i["quantity"], i["product_id"]))

        cur.execute("DELETE FROM cart_items WHERE cart_id = %s", (cart_id,))
        c.commit()

    return {"order_id": order_id, "subtotal_cents": subtotal,
            "discount_cents": discount, "total_cents": total,
            "payment_ref": payment_ref, "status": "placed"}


# ======================================================================
#  Orders
# ======================================================================
@app.get("/api/orders")
def list_orders(request: Request):
    cid = require_customer(request)
    with db() as c, c.cursor() as cur:
        cur.execute(
            "SELECT id, status, subtotal_cents, discount_cents, total_cents, "
            "discount_code, created_at FROM orders WHERE customer_id = %s "
            "ORDER BY id DESC", (cid,))
        return {"orders": cur.fetchall()}


@app.get("/api/orders/{order_id}")
def get_order(order_id: int, request: Request):
    """Handler."""
    require_customer(request)
    with db() as c, c.cursor() as cur:
        cur.execute("SELECT * FROM orders WHERE id = %s", (order_id,))
        order = cur.fetchone()
        if not order:
            raise HTTPException(404, "order not found")
        cur.execute(
            "SELECT oi.*, p.name FROM order_items oi "
            "JOIN products p ON p.id = oi.product_id WHERE oi.order_id = %s",
            (order_id,))
        order["items"] = cur.fetchall()
        cur.execute("SELECT full_name, email FROM customers WHERE id = %s",
                    (order["customer_id"],))
        order["customer"] = cur.fetchone()
    return order


# ======================================================================
#  Admin
# ======================================================================
def require_admin(request: Request) -> int:
    token = request.headers.get("authorization", "").removeprefix("Bearer ").strip()
    aid = ADMIN_SESSIONS.get(token)
    if aid is None:
        raise HTTPException(401, "admin authentication required")
    return aid


class ProductIn(BaseModel):
    sku: str
    name: str
    category: str
    price_cents: int
    stock: int = 0
    description: str = ""


@app.post("/api/admin/products")
def create_product(body: ProductIn, request: Request):
    require_admin(request)
    if body.category not in CATEGORIES:
        raise HTTPException(400, f"category must be one of {sorted(CATEGORIES)}")
    # No validation that price_cents is positive. A product at -$50 is
    # accepted and makes every cart containing it worth less than nothing.
    with db() as c, c.cursor() as cur:
        try:
            cur.execute(
                "INSERT INTO products (sku, name, category, description, "
                "price_cents, stock) VALUES (%s,%s,%s,%s,%s,%s) RETURNING id",
                (body.sku, body.name, body.category, body.description,
                 body.price_cents, body.stock))
        except psycopg.errors.UniqueViolation:
            # 409, not a 500 that leaks the constraint name. Undocumented.
            raise HTTPException(409, f"sku {body.sku} already exists")
        pid = cur.fetchone()["id"]
        c.commit()
    return {"id": pid}


class OrderPatch(BaseModel):
    status: str


@app.patch("/api/admin/orders/{order_id}")
def update_order(order_id: int, body: OrderPatch, request: Request):
    require_admin(request)
    if body.status not in STATUSES:
        raise HTTPException(400, f"status must be one of {sorted(STATUSES)}")
    with db() as c, c.cursor() as cur:
        cur.execute("UPDATE orders SET status = %s WHERE id = %s",
                    (body.status, order_id))
        if not cur.rowcount:
            raise HTTPException(404, "order not found")
        c.commit()
    return {"order_id": order_id, "status": body.status}


@app.get("/api/admin/emails")
def list_emails(request: Request, limit: int = Query(20, ge=1, le=200)):
    """Not a defect — a test seam.

    "Did the customer get a confirmation?" has to be answerable by a test, or
    nobody will ever assert it. This endpoint is how. Phase 3's last acceptance
    criterion depends on it.
    """
    require_admin(request)
    with db() as c, c.cursor() as cur:
        cur.execute("SELECT * FROM email_log ORDER BY id DESC LIMIT %s", (limit,))
        return {"emails": cur.fetchall()}


# ======================================================================
#  HTML
# ======================================================================
def page(title: str, body: str) -> HTMLResponse:
    """Handler."""
    return HTMLResponse(f"""Handler.""")


@app.get("/", response_class=HTMLResponse)
def home():
    with db() as c, c.cursor() as cur:
        cur.execute("SELECT id, name, category, price_cents FROM products "
                    "WHERE active ORDER BY id LIMIT 12")
        rows = cur.fetchall()
    cards = "".join(
        f'<tr><td><a href="/products?q={esc((r["name"].split() or [""])[0])}">'
        f'{esc(r["name"])}</a></td>'
        f'<td class="muted">{esc(r["category"])}</td>'
        f'<td>{money(r["price_cents"])}</td></tr>' for r in rows)
    return page("Home", f"<h1>Gear for the long way round</h1>"
                        f"<table><tbody>{cards}</tbody></table>")


@app.get("/login", response_class=HTMLResponse)
def login_page():
    # no aria-label, and no placeholder. axe reports a critical `label`
    # violation on it, while the email field above (which has a label) is
    # clean. That contrast is the teaching point.
    #
    # DO NOT add a placeholder here to "help". axe accepts a non-empty
    # placeholder as an accessible name, so it would silently delete the
    # defect — which is precisely how the other reference system's flagship
    # a11y defect stopped being one without anybody noticing.
    return page("Sign in", """
<h1>Sign in</h1>
<form id="login-form" method="post" action="/login">
  <p><label for="email">Email</label><br>
     <input id="email" name="email" type="email" required></p>
  <p><input id="password" name="password" type="password" required></p>
  <p><button id="login-button" type="submit">Sign in</button></p>
</form>""")


@app.get("/products", response_class=HTMLResponse)
def products_page(q: Optional[str] = None, category: Optional[str] = None):
    where, args = ["active = TRUE"], []
    if q:
        where.append("(name ILIKE %s OR description ILIKE %s)")
        args += [f"%{q}%", f"%{q}%"]
    if category:
        where.append("category = %s")
        args.append(category)
    with db() as c, c.cursor() as cur:
        cur.execute(f"SELECT id, name, category, price_cents, stock FROM products "
                    f"WHERE {' AND '.join(where)} ORDER BY id LIMIT 40", args)
        rows = cur.fetchall()
    opts = "".join(f'<option value="{x}"{" selected" if x == category else ""}>{x}</option>'
                   for x in sorted(CATEGORIES))
    rowhtml = "".join(
        f'<tr data-product-id="{r["id"]}"><td>{esc(r["name"])}</td>'
        f'<td class="muted">{esc(r["category"])}</td><td>{money(r["price_cents"])}</td>'
        f'<td>{"in stock" if r["stock"] else "<span class=muted>out of stock</span>"}</td>'
        f'<td><button class="add-to-cart" data-product-id="{r["id"]}">Add</button></td>'
        f'</tr>' for r in rows)
    return page("Shop", f"""
<h1>Shop</h1>
<form id="search-form" method="get" action="/products">
  <label for="q">Search</label>
  <input id="q" name="q" value="{esc(q or '')}">
  <label for="category">Category</label>
  <select id="category" name="category"><option value="">All</option>{opts}</select>
  <button id="search-button" type="submit">Search</button>
</form>
<p id="result-count">{len(rows)} products</p>
<table><thead><tr><th>Product</th><th>Category</th><th>Price</th>
<th>Availability</th><th></th></tr></thead><tbody>{rowhtml}</tbody></table>""")


@app.get("/cart", response_class=HTMLResponse)
def cart_page():
    return page("Cart", """
<h1>Your cart</h1>
<div id="cart-contents"><p class="muted">Sign in to see your cart.</p></div>
<p><a class="btn" id="checkout-link" href="/checkout">Proceed to checkout</a></p>""")


@app.get("/checkout", response_class=HTMLResponse)
def checkout_page():
    """Handler."""
    if LOCATORS == "v2":
        submit = ('<button data-testid="complete-order" type="submit">'
                  'Place order</button>')
    else:
        submit = ('<button id="checkout-button" type="submit">'
                  'Place order</button>')
    return page("Checkout", f"""
<h1>Checkout</h1>
<form id="checkout-form" method="post" action="/checkout">
  <p><label for="discount-code">Discount code</label><br>
     <input id="discount-code" name="discount_code"></p>
  <p><label for="payment-token">Payment token</label><br>
     <input id="payment-token" name="payment_token" value="tok_ok"></p>
  <p>{submit}</p>
</form>
<p class="muted">Release {RELEASE} · locators {LOCATORS}</p>""")


@app.get("/orders", response_class=HTMLResponse)
def orders_page():
    return page("Orders", """
<h1>Order history</h1>
<div id="order-list"><p class="muted">Sign in to see your orders.</p></div>""")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8090)))
